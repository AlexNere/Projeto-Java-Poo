/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Conexao.Conexao_JDBC;
import javax.swing.JOptionPane;
import prj_trasegundobi.Pessoa;

public class frm_Cadastro extends javax.swing.JFrame {

    Pessoa excluipessoa = new Pessoa();
    Pessoa getpessoa = new Pessoa();
        
    private Conexao_JDBC conx;
    private int sexo;
     
    public frm_Cadastro() {
        initComponents();
        carregarDados();
    }
    
    
    private void carregarDados()
    {
         conx=new Conexao_JDBC();
        conx.getConection();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jtxt_Nome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jcomb_cargo = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        area_texto = new javax.swing.JTextArea();
        btnInserir = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnPesquisar = new javax.swing.JButton();
        jcomb_estCivil = new javax.swing.JComboBox<>();
        rdMasculino = new javax.swing.JRadioButton();
        rdFeminino = new javax.swing.JRadioButton();
        rdOutros = new javax.swing.JRadioButton();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jtxt_nasc = new javax.swing.JFormattedTextField();
        jtxt_tel = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nome:");

        jtxt_Nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_NomeActionPerformed(evt);
            }
        });

        jLabel2.setText("Nascimento:");

        jLabel3.setText("Telefone:");

        jLabel4.setText("Estado Civil");

        jLabel5.setText("Sexo");

        jLabel6.setText("Cargo");

        jLabel7.setText("Local de treinamento:");

        jcomb_cargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Gerente", "Master", "Coordenador", "Supervisor", "Especialista", "Sênior", "Pleno", "Junior", "Trainee", "Jovem Aprendiz", "Estágiario" }));

        area_texto.setColumns(20);
        area_texto.setRows(5);
        area_texto.setText("Treinamento de :");
        area_texto.setToolTipText("");
        area_texto.setHighlighter(null);
        jScrollPane1.setViewportView(area_texto);

        btnInserir.setText("Inserir");
        btnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        jcomb_estCivil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Casado", "Solteiro", "Separado", "Divorciado", "União Estável", "Outro" }));
        jcomb_estCivil.setToolTipText("0");
        jcomb_estCivil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcomb_estCivilActionPerformed(evt);
            }
        });

        rdMasculino.setText("Masculino");
        rdMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdMasculinoActionPerformed(evt);
            }
        });

        rdFeminino.setText("Feminino");
        rdFeminino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdFemininoActionPerformed(evt);
            }
        });

        rdOutros.setText("Outros");
        rdOutros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdOutrosActionPerformed(evt);
            }
        });

        jLabel8.setText("Cadastro para treinamento");

        jButton1.setText("Limpar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        try {
            jtxt_nasc.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxt_nasc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_nascActionPerformed(evt);
            }
        });

        try {
            jtxt_tel.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxt_tel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxt_telActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jcomb_cargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rdMasculino)
                                .addGap(18, 18, 18)
                                .addComponent(rdFeminino)
                                .addGap(10, 10, 10)
                                .addComponent(rdOutros))
                            .addComponent(jtxt_tel, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jcomb_estCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxt_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxt_nasc, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(btnEditar)
                        .addGap(26, 26, 26)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(btnInserir)
                        .addGap(34, 34, 34)
                        .addComponent(btnExcluir)
                        .addGap(18, 18, 18)
                        .addComponent(btnPesquisar)))
                .addContainerGap(18, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(134, 134, 134))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtxt_Nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jtxt_nasc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtxt_tel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jcomb_estCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rdMasculino)
                        .addComponent(rdFeminino)
                        .addComponent(rdOutros)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcomb_cargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInserir)
                    .addComponent(btnExcluir)
                    .addComponent(btnPesquisar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditar)
                    .addComponent(jButton1))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirActionPerformed
        // TODO add your handling code here:
          
          
        String auxNome= this.jtxt_Nome.getText();
        String auxNasc= this.jtxt_nasc.getText();
        String auxTelefone= this.jtxt_tel.getText();
        int auxEstadoCivil =  this.jcomb_cargo.getSelectedIndex();
        int auxsexo =  this.sexo;
        int auxCargo =  this.jcomb_estCivil.getSelectedIndex();
        String auxObservacao= this.area_texto.getText();
        
        
        
        if( isEmbranco(auxNome,"Nome") )return;
        if( isEmbranco(auxNasc,"Data de nascimento") )return;
        if( isEmbranco(auxTelefone,"Telefone") )return;
        
          if(auxEstadoCivil == -1)
        {    javax.swing.JOptionPane.
                showMessageDialog(null,
            "Escolha o Estado Civil");
        }
          if( auxsexo == 0)
        {
            javax.swing.JOptionPane.
        showMessageDialog(null,"Escolha o Sexo");
        }
           if(auxCargo == -1)
        {    javax.swing.JOptionPane.
                showMessageDialog(null,
            "Escolha seu Cargo");
        }
        if( isEmbranco(auxObservacao,"Treinamento") )return;
       if( isTelefone(auxTelefone)==false)
            return;
                       
        conx.inserir(getDados());
                     
        limpaDados();
    }//GEN-LAST:event_btnInserirActionPerformed
    
    public boolean isNumber(String aux)
    {
        try{
          long auxi= Long.parseLong(aux);
        }catch(Exception e){
            System.out.println("erro:"+e);
            return false;
        }
        return true;
    }
 
     public boolean isTelefone(String aux)
    {
        
       if( aux.indexOf("(")<0 
              ||
           aux.indexOf(")")<0
               ||
            aux.indexOf("-")<0   
          ) 
       {  javax.swing.JOptionPane.
  showMessageDialog(null,"Telefone Inválido");
            return false;
       }
       
        if(
         aux.substring(
                aux.indexOf("(")+1,
                aux.indexOf(")")               
                ).length()<2
        ){
             javax.swing.JOptionPane.
  showMessageDialog(null,"Telefone Inválido: DDD");
            return false;
        }
            
        
        if(
         aux.substring(
                aux.indexOf(")")+1,
                aux.indexOf("-")               
                ).length()< 4
                ||
                aux.substring(
                aux.indexOf(")")+1,
                aux.indexOf("-")               
                ).length()>=6
          )
        {
             javax.swing.JOptionPane.
  showMessageDialog(null,"Telefone Inválido: Antes do traço");
            return false;
        }
        
        if(
         aux.substring(
                aux.indexOf("-")+1,
                aux.length()
                ).length() < 4
                
                ||
                aux.substring(
                aux.indexOf("-")+1,
                aux.length()
                ).length() > 5 
                
        ){
             javax.swing.JOptionPane.
  showMessageDialog(null,"Telefone Inválido: Após o traço");
            return false;
        }
       
       aux =  aux.replace("(", "");
       aux =  aux.replace(")", "");
       aux =  aux.replace("-", "");
       
       if(isNumber(aux)==false)
       {
           javax.swing.JOptionPane.
  showMessageDialog(null,"Telefone Inválido");
           return false;
       }       
       if( aux.length() <8 || aux.length() > 11)
       {
           javax.swing.JOptionPane.
  showMessageDialog(null,"Telefone Inválido");
           return false;
       }
       
       return true;
    }
     
    public boolean isEmbranco(String aux,String msg){
        if( aux.isEmpty())
        {    
           javax.swing.JOptionPane.
    showMessageDialog(null,
            "Campo "+msg+" Em Branco");
           return true;  
        }
        return false;
    }
    
  

    private void jtxt_NomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_NomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_NomeActionPerformed

    private void rdMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdMasculinoActionPerformed
        // TODO add your handling code here:
        this.rdFeminino.setSelected(false);
        this.rdOutros.setSelected(false);
        this.rdMasculino.setSelected(true);
        this.sexo = 1;
    }//GEN-LAST:event_rdMasculinoActionPerformed

    private void rdFemininoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdFemininoActionPerformed
        // TODO add your handling code here:
        this.rdFeminino.setSelected(true);
        this.rdOutros.setSelected(false);
        this.rdMasculino.setSelected(false);
        this.sexo = 2;
    }//GEN-LAST:event_rdFemininoActionPerformed

    private void rdOutrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdOutrosActionPerformed
        // TODO add your handling code here:
        this.rdFeminino.setSelected(false);
        this.rdOutros.setSelected(true);
        this.rdMasculino.setSelected(false);
        this.sexo = 3;
    }//GEN-LAST:event_rdOutrosActionPerformed

    public void setDados(Pessoa pessoa)
    {
        this.jtxt_Nome.setText(pessoa.getNome());
        this.jtxt_nasc.setText(pessoa.getNascimento());
        this.jtxt_tel.setText(pessoa.getTelefone());
        this.area_texto.setText(pessoa.getObservacao());   
        
        if(pessoa.getSexo() == 1)
        {this.rdMasculino.setSelected(true);
         this.rdFeminino.setSelected(false); 
         this.rdOutros.setSelected(false);
        }
        if(pessoa.getSexo() == 2)
        {this.rdMasculino.setSelected(false);
         this.rdFeminino.setSelected(true);
         this.rdOutros.setSelected(false);
        }
        if(pessoa.getSexo() == 3)
        {this.rdMasculino.setSelected(false);
        this.rdFeminino.setSelected(false);
        this.rdOutros.setSelected(true);
        }
        else if(pessoa.getSexo() == 4)
        {this.rdMasculino.setSelected(false);
        this.rdFeminino.setSelected(false);
        this.rdOutros.setSelected(false);
            
        }
        
        if(pessoa.getEstadoCivil() == 0){
            this.jcomb_estCivil.setSelectedIndex(0);
        }else if(pessoa.getEstadoCivil() == 1){    
            this.jcomb_estCivil.setSelectedIndex(1);
        }else if(pessoa.getEstadoCivil() == 2){    
            this.jcomb_estCivil.setSelectedIndex(2);
        }else if(pessoa.getEstadoCivil() == 3){    
            this.jcomb_estCivil.setSelectedIndex(3);
        }else if(pessoa.getEstadoCivil() == 4){    
            this.jcomb_estCivil.setSelectedIndex(4);
        }else if(pessoa.getEstadoCivil() == 5){    
            this.jcomb_estCivil.setSelectedIndex(5);
        }
        
               
        if(pessoa.getCargo() == 0){
            this.jcomb_cargo.setSelectedIndex(0);
        }else if(pessoa.getCargo() == 1){    
            this.jcomb_cargo.setSelectedIndex(1);
        }else if(pessoa.getCargo() == 2){    
            this.jcomb_cargo.setSelectedIndex(2);
        }else if(pessoa.getCargo() == 3){    
            this.jcomb_cargo.setSelectedIndex(3);
        }else if(pessoa.getCargo() == 4){    
            this.jcomb_cargo.setSelectedIndex(4);
        }else if(pessoa.getCargo() == 5){    
            this.jcomb_cargo.setSelectedIndex(5);
        }else if(pessoa.getCargo() == 6){    
            this.jcomb_cargo.setSelectedIndex(6);
        }else if(pessoa.getCargo() == 7){    
            this.jcomb_cargo.setSelectedIndex(7);
        }else if(pessoa.getCargo() == 8){    
            this.jcomb_cargo.setSelectedIndex(8);
        }else if(pessoa.getCargo() == 9){    
            this.jcomb_cargo.setSelectedIndex(9);
        }else if(pessoa.getCargo() == 10){    
            this.jcomb_cargo.setSelectedIndex(10);
        }else if(pessoa.getCargo() == 11){    
            this.jcomb_cargo.setSelectedIndex(11);
        }
        
    }
    
    
     public Pessoa getDados()
    {
        getpessoa.setNome(this.jtxt_Nome.getText());
        getpessoa.setNascimento(this.jtxt_nasc.getText());
        getpessoa.setTelefone(this.jtxt_tel.getText());
        getpessoa.setEstadoCivil(this.jcomb_estCivil.getSelectedIndex());
        getpessoa.setSexo(this.sexo);
        getpessoa.setCargo(this.jcomb_cargo.getSelectedIndex());
        getpessoa.setObservacao(this.area_texto.getText());   
       
        
        return getpessoa;        
    }
     
    public void limpaDados()
    {
        this.jtxt_Nome.setText("");
        this.jtxt_nasc.setText("");
        this.jtxt_tel.setText("");
        this.jcomb_estCivil.setSelectedIndex(-1);
        this.rdFeminino.setSelected(false);
        this.rdMasculino.setSelected(false);
        this.rdOutros.setSelected(false);
        this.jcomb_cargo.setSelectedIndex(-1);
        this.area_texto.setText("");   
            
    }

    
    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        
         
        conx.update(getDados());
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        // TODO add your handling code here:
        
        if(excluipessoa == null){
            JOptionPane.showMessageDialog(null,"Nenhum funcionário selecionado !");
        }else{
            conx.remover(excluipessoa.getCodigo());
            limpaDados();
        }
        
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        // TODO add your handling code here:
          
        String Nome=javax.swing.JOptionPane.showInputDialog("Digite o nome para Pesquisar");
        while(Nome.equals("")){
            Nome=javax.swing.JOptionPane.showInputDialog("Digite o nome para Pesquisar");
        }
        Pessoa pessoa = new Pessoa();
        pessoa = conx.pesquisar(Nome);
        
        if (pessoa == null ){
             JOptionPane.showMessageDialog(null,"Nenhum funcionário encontrado !");
        }else{
             setDados(pessoa);
             excluipessoa = pessoa;
             getpessoa = pessoa;
        }
       
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          limpaDados();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jcomb_estCivilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcomb_estCivilActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcomb_estCivilActionPerformed

    private void jtxt_nascActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_nascActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jtxt_nascActionPerformed

    private void jtxt_telActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxt_telActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxt_telActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frm_Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frm_Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frm_Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frm_Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frm_Cadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea area_texto;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnInserir;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jcomb_cargo;
    private javax.swing.JComboBox<String> jcomb_estCivil;
    private javax.swing.JTextField jtxt_Nome;
    private javax.swing.JFormattedTextField jtxt_nasc;
    private javax.swing.JFormattedTextField jtxt_tel;
    private javax.swing.JRadioButton rdFeminino;
    private javax.swing.JRadioButton rdMasculino;
    private javax.swing.JRadioButton rdOutros;
    // End of variables declaration//GEN-END:variables
}
