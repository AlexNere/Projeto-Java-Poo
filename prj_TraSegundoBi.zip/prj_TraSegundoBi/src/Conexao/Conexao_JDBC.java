package Conexao;

import java.sql.*;

public class Conexao_JDBC {
   private Connection con;
   public Connection getConection()
   {
       try{
           Class.forName("com.mysql.jdbc.Driver");
           
           con =DriverManager.getConnection(
                    "jdbc:mysql://localhost/clientes",
                    "root",
                    "");
         
       }catch(Exception e)
       {  System.out.println("Erro:"+e);  }
       
       return con;
   }
   
   private Statement stm=null;
   private ResultSet resultado=null;
   public String[] getDados()
   {
       String dados[]=new String[7];
       
       try{
           if(stm == null)
           {
               stm=con.createStatement();           
               resultado = 
               stm.executeQuery("Select * from cadastro");
               resultado.next();
           }
           
           for(int i=0; i< 7;i++)
           dados[i]=resultado.getString(i+1);
           //dados[0]=resultado.getString(1);
           //dados[1]=resultado.getString(2);
           return dados;
           
       }catch(Exception e)
       {           System.out.println("Erro:"+e);       }
       
       return null;
   }
    
   public void proximo()
   {
       try{
           if(resultado==null)
               return;
            resultado.next();
       }catch(Exception e)
       {System.out.println("Erro:"+e);   }
   }
   
        /*
        dadosaux[0]=this.txtNome.getText();
        dadosaux[1]=this.txtEmail.getText();
        dadosaux[2]=this.txtTelefone.getText();
        dadosaux[3]=this.cboEstadoCivil.getSelectedIndex()+"";
        dadosaux[4]=this.sexo+"";        
        dadosaux[5]=this.txtAObservacao.getText();                
        
        */
    
  private int getLastCodigo()
  { int codigo=1;
       try{           
            this.resultado.last();
            codigo=this.resultado.getInt(7)+1;
            this.resultado.beforeFirst();
       }catch(Exception e){System.out.println("Erro:"+e);}
      return codigo;
  }
   public void inserir(String aux[])
   {
       String sql="Insert into cadastro values ("
               +"'"+aux[0]+"',"
               +"'"+aux[1]+"',"
               +"'"+aux[2]+"',"
               +""+aux[3]+","
               +""+aux[4]+","
               +"'"+aux[5]+"',"
               +""+getLastCodigo()
               +")";
       this.executar(sql);
   }
   public void remover(String aux[])
   {
        String sql="Delete from cadastro "              
               +" where codigo="+aux[6] + ";";               
       this.executar(sql);
       
   }
   public void update(String aux[])
   {
       String sql="Update  cadastro SET "
               +" nome='"+aux[0]+"',"
               +" email='"+aux[1]+"',"
               +" telefone='"+aux[2]+"',"
               +" estadocivil="+aux[3]+","
               +"sexo="+aux[4]+","
               +"observacao='"+aux[5]+"' "
               +" where codigo="+aux[6] + ";";
               
       this.executar(sql);
       
   }
   public boolean  pesquisar(int campo, String dados)
   {       
       try{
           
           resultado.beforeFirst();
           while(resultado.next())
           {
               if(resultado.getString(campo).equals(dados))
               {   getDados();
                   return true;
               }
           }
       
       }catch(Exception e){ System.out.println("Erro:"+e);   }       
       
       return false;
   }
   private void executar(String sql)
   {
       
         try{      
              stm.execute(sql); 
              stm=null;
              this.getDados();
             
          
       }catch(Exception e)
       {System.out.println("Erro:"+e);   } 
   }
   public void anterior()
   {
       try{
           if(resultado==null)
               return;
            resultado.previous();
       }catch(Exception e)
       {System.out.println("Erro:"+e);   }
   }
   public void ultimo()
   {
       try{
           if(resultado==null)
               return;
            resultado.last();
       }catch(Exception e)
       {System.out.println("Erro:"+e);   }
   }
   
   public void primeiro()
   {
       try{
           if(resultado==null)
               return;
            resultado.first();
       }catch(Exception e)
       {System.out.println("Erro:"+e);   }
   }
   
}
