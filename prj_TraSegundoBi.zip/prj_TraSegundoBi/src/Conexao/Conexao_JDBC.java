package Conexao;

import java.sql.*;
import javax.swing.JOptionPane;
import prj_trasegundobi.Pessoa;

public class Conexao_JDBC {
   private Connection con;
   
    Pessoa pessoa = new Pessoa();
 
   public Connection getConection()
   {
       try{
           Class.forName("com.mysql.jdbc.Driver");
           
           con =DriverManager.getConnection(
                    "jdbc:mysql://localhost/empresa",
                    "root",
                    "");
         
       }catch(Exception e)
       {  System.out.println("Erro:"+e);  }
       
       return con;
   }
   
   private Statement stm=null;
   private ResultSet resultado=null;
   
   public String[] getDados()
   {
       String dados[]=new String[8];
       
       try{
           if(stm == null)
           {
               stm=con.createStatement();           
               
               stm.execute("Select * from funcionario");
               
               resultado = stm.getResultSet();
               
           }
           while(resultado.next()){
            for(int i=0; i< 8;i++){
            dados[i]=resultado.getString(i+1);
            }
           }
           return dados;
           
       }catch(Exception e)
       {           System.out.println("Erro:"+e);       }
       
       return null;
   }
   

    

   public void inserir( Pessoa pessoa )
   {
       
       String sql="INSERT INTO `funcionario`(`Nome`, `Nascimento`, `Telefone`, `Estcivil`, `Sexo`, `Cargo`, `Observacao`) VALUES "
               + "("
               +"'"+pessoa.getNome()+"',"
               +"'"+pessoa.getNascimento()+"',"
               +"'"+pessoa.getTelefone()+"',"
               +""+pessoa.getEstadoCivil()+","
               +""+pessoa.getSexo()+","
               +""+pessoa.getCargo()+","
               +"'"+pessoa.getObservacao()+"'"
               +");";
       
       execute(sql);
       
       JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso !" );
   }
   
   public void remover(int codigo)
   {
        String sql="Delete from funcionario "              
               +" where Codigo="+codigo + ";";               
       this.execute(sql);
       JOptionPane.showMessageDialog(null,"Item Excluído" );
   }
   
   public void update(Pessoa pessoa)
   {
       String sql="Update  funcionario SET "
               +" Nome='"+pessoa.getNome()+"',"
               +" Nascimento='"+pessoa.getNascimento()+"',"
               +" Telefone='"+pessoa.getTelefone()+"',"
               +" Estcivil="+pessoa.getEstadoCivil()+","
               +"Sexo="+pessoa.getSexo()+","
               +"Cargo="+pessoa.getCargo()+","
               +"Observacao='"+pessoa.getObservacao()+"'"
               +" where Codigo="+pessoa.getCodigo()+ ";";
      
       this.execute(sql);
       JOptionPane.showMessageDialog(null,"Item Atualizado" );
   }
   
   public Pessoa pesquisar(String dados)
   {       
       String[] result;
       try{
           
               stm=con.createStatement();           
               
               stm.execute("Select * from funcionario where Nome='"+dados+"'");
               
               resultado = stm.getResultSet();               
               {
                   while(resultado.next()){
                   pessoa.setCodigo(resultado.getInt(1));
                   pessoa.setNome(resultado.getString(2));
                   pessoa.setNascimento(resultado.getString(3));
                   pessoa.setTelefone(resultado.getString(4));
                   pessoa.setEstadoCivil(resultado.getInt(5));
                   pessoa.setSexo(resultado.getInt(6));
                   pessoa.setCargo(resultado.getInt(7));
                   pessoa.setObservacao(resultado.getString(8));
                    }
                   
               
               
           }
               
       }catch(Exception e){ System.out.println("Erro:"+e);   }       
       
       return pessoa;
   }
   
   public void execute(String sql)
   {
        
        try{
             stm=con.createStatement();      
             stm.execute(sql); 
             
          
        }catch(SQLException e){
            System.out.println("Erro:"+e);   
        } 
   }

   
}
