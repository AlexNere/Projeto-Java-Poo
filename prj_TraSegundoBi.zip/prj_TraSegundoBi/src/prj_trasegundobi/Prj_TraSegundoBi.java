
package prj_trasegundobi;

import view.frm_Cadastro;

public class Prj_TraSegundoBi {

    public static void main(String[] args) {
    
        frm_Cadastro cad = new frm_Cadastro();
        cad.setVisible(true);
        
        
    }
    
}
