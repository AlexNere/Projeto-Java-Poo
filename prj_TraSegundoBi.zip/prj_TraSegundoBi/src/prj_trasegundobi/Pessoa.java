package prj_trasegundobi;

public class  Pessoa {
    
    private String Nome;
    private String Nascimento;
    private String Telefone;
    private String Observacao;
    private int EstadoCivil;
    private int Sexo;
    private int Cargo;
    private int Codigo;
   
    


    /**
     * @return the observacao
     */
    public String getObservacao() {
        return Observacao;
    }

    /**
     * @param observacao the observacao to set
     */
    public void setObservacao(String observacao) {
        this.Observacao = observacao;
    }
    
    
    /**
     * @return the nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.Nome = nome;
    }

    /**
     * @return the nascimento
     */
    public String getNascimento() {
        return Nascimento;
    }

    /**
     * @param nascimento the nascimento to set
     */
    public void setNascimento(String nascimento) {
        this.Nascimento = nascimento;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return Telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.Telefone = telefone;
    }

    /**
     * @return the estadoCivil
     */
    public int getEstadoCivil() {
        return EstadoCivil;
    }

    /**
     * @param estadoCivil the estadoCivil to set
     */
    public void setEstadoCivil(int estadoCivil) {
        this.EstadoCivil = estadoCivil;
    }

    /**
     * @return the sexo
     */
    public int getSexo() {
        return Sexo;
    }

    /**
     * @param sexo the sexo to set
     */
    public void setSexo(int sexo) {
        this.Sexo = sexo;
    }

    /**
     * @return the cargo
     */
    public int getCargo() {
        return Cargo;
    }

    /**
     * @param cargo the cargo to set
     */
    public void setCargo(int cargo) {
        this.Cargo = cargo;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return Codigo;
    }
    
    public void setCodigo(int codigo){
        this.Codigo = codigo;        
    }
    
    
}
