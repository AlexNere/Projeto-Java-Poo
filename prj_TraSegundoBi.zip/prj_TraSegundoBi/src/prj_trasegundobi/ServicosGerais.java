
package prj_trasegundobi;

public class ServicosGerais {
    private int especificacao;

    /**
     * @return the especificacao
     */
    public int getEspecificacao() {
        return especificacao;
    }

    /**
     * @param especificacao the especificacao to set
     */
    public void setEspecificacao(int especificacao) {
        this.especificacao = especificacao;
    }
}
